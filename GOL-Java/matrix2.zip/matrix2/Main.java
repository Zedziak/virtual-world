package pl.edu.pg.eti.ksg.po.project2;

public class Main {
    public static void main(String[] args) {
        SwiatGUI swiatGUI = new SwiatGUI("Wirtualny swiat");
    }
}